package loop;

public class Main02 {

	public static void main(String[] args) {
		// 구구단 7단의 결과 값
		// 11시 30분
		
		int j = 0;
		
		for( int i = 1; i < 10; i++ ) {
			j = 7 * i;
			System.out.println(j);
		}
		
		
		
		
	}

}












