package multiex;

public class Main01 {

	public static void main(String[] args) {
		int target = 100;
//		int num = 0;
		
		if( target == 100 ) {
			int num = target + 100;
			System.out.println(num);
		} else {
			int num = target - 100;
			System.out.println(num);
		}
		
		int num = 105;
		System.out.println(num);
		
		
	}

}
