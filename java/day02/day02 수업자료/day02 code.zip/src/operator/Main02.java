package operator;

public class Main02 {

	public static void main(String[] args) {
		// 나눗셈
		// 0으로 나누기
		int num = 100;
		int zero = 0;
		int result1 = num / zero;
		
		System.out.println(result1);
	}

}
