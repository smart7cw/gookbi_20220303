package operator;

public class Main01 {

	public static void main(String[] args) {
		int num1 = 12;
		int num2 = 8;

		// + 
		int result1 = num1 + num2;
		
		// -
		int result2 = num1 - num2;
		
		// *
		int result3 = num1 * num2;
		
		// /
		int result4 = num1 / num2;
		
		// %
		int result5 = num1 % num2;
		
		
		System.out.println("result1 : " + result1);
		System.out.println("result2 : " + result2);
		System.out.println("result3 : " + result3);
		System.out.println("result4 : " + result4);
		System.out.println("result5 : " + result5);
		
		
		
		
	}

}
