package hiding;

class StudentJava{
	// 은닉된 멤버변수 -> 현재 블록 안에서만 접근 가능함.
	private String name;
	private int age;
	
	
	
}

public class Main02 {

	public static void main(String[] args) {
		
		
		
		
		
	}

}












