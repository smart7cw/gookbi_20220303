package condition;

public class Main03 {

	public static void main(String[] args) {
		boolean is_korean = true;
		
		//if( is_korean == true ) {
		if( is_korean ) {
			System.out.println("한국사람 입니다.");
		} else {
			System.out.println("한국 사람이 아닙니다.");
		}
		
	}

}





