package condition;

public class Main04 {

	public static void main(String[] args) {
		int point = 90;
		
		if( 90 < point && point <= 100 ) {
			System.out.println("A");
		} else if( 80 < point && point <= 90 ) {
			System.out.println("B");
		} else if( 70 < point && point <= 80 ) {
			System.out.println("C");
		} else {
			System.out.println("F");
		}
		
		
		
	}

}
